#include "gba.h"
#include "print.h"

#include "game.h"

u16 buttons, oldButtons;

void initialize();

int main() {

    initialize();

    while (1) {
        
        if (winCondition) {
            fillScreen(GREEN);
            break;

        } else {

            oldButtons = buttons;
            buttons = REG_BUTTONS;
            
            updateGame();
            waitForVBlank();
            drawGame();

        } // if

    } // while
    
    return 0;

} // main

void initialize() {
    
    mgba_open();
    REG_DISPCTL = MODE(3) | BG_ENABLE(2);

    oldButtons = 0;
    buttons = REG_BUTTONS;

    initGame();

} // initialize