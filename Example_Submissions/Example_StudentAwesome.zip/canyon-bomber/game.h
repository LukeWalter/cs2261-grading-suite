#ifndef GAME_H
#define GAME_H

typedef struct {
    int x, y, width, height;
    int oldX, oldY;
    int dx, dy;
    int active, erased;
    unsigned short color;

} RECTANGLE;

extern int winCondition;

void initGame();
void updateGame();
void drawGame();

int winCheck();

#endif