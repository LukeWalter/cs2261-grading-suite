#include <stdlib.h>
#include "gba.h"
#include "print.h"

#include "game.h"

int winCondition;
unsigned short backgroundColor, stoneColor;

RECTANGLE plane;
RECTANGLE bomb;

RECTANGLE terrain1[20];
RECTANGLE terrain2[20];
RECTANGLE terrain3[16];
RECTANGLE terrain4[16];

void initGame() {
    
    backgroundColor = RGB(15, 15, 31);
    stoneColor = RGB(12, 12, 12);

    // Setup background scene
    fillScreen(backgroundColor);
    drawRectangle(0, 140, SCREENWIDTH, 20, stoneColor);
    drawRectangle(0, 120, 40, 20, stoneColor);
    drawRectangle(200, 120, 40, 20, stoneColor);
    drawRectangle(0, 100, 20, 20, stoneColor);
    drawRectangle(220, 100, 20, 20, stoneColor);

    // Initialize plane variables
    plane.x = 16;
    plane.y = 20;
    plane.dx = 1;
    plane.dy = 0;

    plane.width = 16;
    plane.height = 8;

    plane.color = RED;

    // Initialize bomb variables
    bomb.dy = 2;
    bomb.width = 2;
    bomb.height = 2;
    bomb.color = WHITE;
    bomb.active = 0;
    bomb.erased = 1;

    // Initialize terrain variables

    for (int i = 0; i < 20; i++) {
        
        terrain1[i].x = 20 + 10 * i;
        terrain1[i].y = 100;
        terrain1[i].oldX = terrain1[i].x;
        terrain1[i].oldY = terrain1[i].y;

        terrain1[i].width = 10;
        terrain1[i].height = 10;

        terrain1[i].color = RGB(0, 31 - i, 0);
        terrain1[i].active = 1;
        terrain1[i].erased = 0;

        drawRectangle(terrain1[i].x, terrain1[i].y, terrain1[i].width, terrain1[i].height, terrain1[i].color);

    } // for

    for (int i = 0; i < 20; i++) {
        
        terrain2[i].x = 20 + 10 * i;
        terrain2[i].y = 110;
        terrain2[i].oldX = terrain2[i].x;
        terrain2[i].oldY = terrain2[i].y;

        terrain2[i].width = 10;
        terrain2[i].height = 10;

        terrain2[i].color = RGB(0, 30 - i, 0);
        terrain2[i].active = 1;
        terrain2[i].erased = 0;

        drawRectangle(terrain2[i].x, terrain2[i].y, terrain2[i].width, terrain2[i].height, terrain2[i].color);

    } // for

    for (int i = 0; i < 16; i++) {
        
        terrain3[i].x = 40 + 10 * i;
        terrain3[i].y = 120;
        terrain3[i].oldX = terrain3[i].x;
        terrain3[i].oldY = terrain3[i].y;

        terrain3[i].width = 10;
        terrain3[i].height = 10;

        terrain3[i].color = RGB(0, 27 - i, 0);
        terrain3[i].active = 1;
        terrain3[i].erased = 0;

        drawRectangle(terrain3[i].x, terrain3[i].y, terrain3[i].width, terrain3[i].height, terrain3[i].color);

    } // for

    for (int i = 0; i < 16; i++) {
        
        terrain4[i].x = 40 + 10 * i;
        terrain4[i].y = 130;
        terrain4[i].oldX = terrain4[i].x;
        terrain4[i].oldY = terrain4[i].y;

        terrain4[i].width = 10;
        terrain4[i].height = 10;

        terrain4[i].color = RGB(0, 26 - i, 0);
        terrain4[i].active = 1;
        terrain4[i].erased = 0;

        drawRectangle(terrain4[i].x, terrain4[i].y, terrain4[i].width, terrain4[i].height, terrain4[i].color);

    } // for

} // initGame

void updateGame() {
    
    // Plane movement
    plane.oldX = plane.x;
    plane.oldY = plane.y;

    if (plane.x < 1 || plane.x > SCREENWIDTH - plane.width - plane.dx) plane.dx *= -1;
    
    int speed = (BUTTON_HELD(BUTTON_SELECT)) ? 2 : 1;
    plane.x += plane.dx * speed;

    // Fire bomb
    if (BUTTON_PRESSED(BUTTON_B) && !bomb.active) {
        
        bomb.x = plane.x + (plane.width / 2);
        bomb.y = plane.y + plane.height;
        bomb.dx = plane.dx * speed;

        bomb.active = 1;
        bomb.erased = 0;

    } // if

    // Active bomb behavior
    if (bomb.active) {

        // Bomb movement
        bomb.oldX = bomb.x;
        bomb.oldY = bomb.y;

        bomb.x += bomb.dx;
        bomb.y += bomb.dy;

        // Collision detection
        for (int i = 0; i < 20; i++) {

            if (collision(bomb.x, bomb.y, bomb.width, bomb.height, 
            terrain1[i].x, terrain1[i].y, terrain1[i].width, terrain1[i].height)) {
                terrain1[i].active = 0;

            } // if

            if (collision(bomb.x, bomb.y, bomb.width, bomb.height, 
            terrain2[i].x, terrain2[i].y, terrain2[i].width, terrain2[i].height)) {
                terrain2[i].active = 0;

            } // if

            if (i > 15) continue;

            if (collision(bomb.x, bomb.y, bomb.width, bomb.height, 
            terrain3[i].x, terrain3[i].y, terrain3[i].width, terrain3[i].height)) {
                terrain3[i].active = 0;

            } // if

            if (collision(bomb.x, bomb.y, bomb.width, bomb.height, 
            terrain4[i].x, terrain4[i].y, terrain4[i].width, terrain4[i].height)) {
                terrain4[i].active = 0;

            } // if

        } // for

        // Deactivate once reaching ground or bottom of screen
        if (bomb.y > 159 || bomb.x < 0 || bomb.x > SCREENWIDTH
        || videoBuffer[OFFSET(bomb.x + bomb.dx, bomb.y + bomb.dy, 240)] == stoneColor) {
            bomb.active = 0;

        } // if

    } // if

    // Terrain falling behavior

    for (int i = 0; i < 20; i++) {

        terrain1[i].oldY = terrain1[i].y;
        terrain2[i].oldY = terrain2[i].y;

        if (terrain1[i].active && videoBuffer[OFFSET(terrain1[i].x, terrain1[i].y + terrain1[i].height, 240)] == backgroundColor) {
            terrain1[i].y += 1;

        } // if

        if (terrain2[i].active && videoBuffer[OFFSET(terrain2[i].x, terrain2[i].y + terrain2[i].height, 240)] == backgroundColor) {
            terrain2[i].y += 1;

        } // if

        if (i > 15) continue;

        terrain3[i].oldY = terrain3[i].y;
        terrain4[i].oldY = terrain4[i].y;

        if (terrain3[i].active && videoBuffer[OFFSET(terrain3[i].x, terrain3[i].y + terrain3[i].height, 240)] == backgroundColor) {
            terrain3[i].y += 1;

        } // if

        if (terrain4[i].active && videoBuffer[OFFSET(terrain4[i].x, terrain4[i].y + terrain4[i].height, 240)] == backgroundColor) {
            terrain4[i].y += 1;

        } // if

    } // for

    winCondition = winCheck();

} // updateGame

void drawGame() {

    // Drawing plane
    drawRectangle(plane.oldX, plane.oldY, plane.width, plane.height, backgroundColor);
    drawRectangle(plane.x, plane.y, plane.width, plane.height, plane.color);

    // Drawing moving terrain / erasing destroyed terrain
    for (int i = 0; i < 20; i++) {

        if (!terrain1[i].active && !terrain1[i].erased) {
            drawRectangle(terrain1[i].x, terrain1[i].y, terrain1[i].width, terrain1[i].height, backgroundColor);
            terrain1[i].erased = 1;

        } else if (terrain1[i].oldY != terrain1[i].y) {
            drawRectangle(terrain1[i].oldX, terrain1[i].oldY, terrain1[i].width, terrain1[i].height, backgroundColor);
            drawRectangle(terrain1[i].x, terrain1[i].y, terrain1[i].width, terrain1[i].height, terrain1[i].color);

        } // if

        if (!terrain2[i].active && !terrain2[i].erased) {
            drawRectangle(terrain2[i].x, terrain2[i].y, terrain2[i].width, terrain2[i].height, backgroundColor);
            terrain2[i].erased = 1;

        } else if (terrain2[i].oldY != terrain2[i].y) {
            drawRectangle(terrain2[i].oldX, terrain2[i].oldY, terrain2[i].width, terrain2[i].height, backgroundColor);
            drawRectangle(terrain2[i].x, terrain2[i].y, terrain2[i].width, terrain2[i].height, terrain2[i].color);

        } // if

        if (i > 15) continue;

        if (!terrain3[i].active && !terrain3[i].erased) {
            drawRectangle(terrain3[i].x, terrain3[i].y, terrain3[i].width, terrain3[i].height, backgroundColor);
            terrain3[i].erased = 1;

        } else if (terrain3[i].oldY != terrain3[i].y) {
            drawRectangle(terrain3[i].oldX, terrain3[i].oldY, terrain3[i].width, terrain3[i].height, backgroundColor);
            drawRectangle(terrain3[i].x, terrain3[i].y, terrain3[i].width, terrain3[i].height, terrain3[i].color);

        } // if

        if (!terrain4[i].active && !terrain4[i].erased) {
            drawRectangle(terrain4[i].x, terrain4[i].y, terrain4[i].width, terrain4[i].height, backgroundColor);
            terrain4[i].erased = 1;

        } else if (terrain4[i].oldY != terrain4[i].y) {
            drawRectangle(terrain4[i].oldX, terrain4[i].oldY, terrain4[i].width, terrain4[i].height, backgroundColor);
            drawRectangle(terrain4[i].x, terrain4[i].y, terrain4[i].width, terrain4[i].height, terrain4[i].color);

        } // if

    } // for

    // Drawing plane while active
    if (bomb.active) {
        drawRectangle(bomb.oldX, bomb.oldY, bomb.width, bomb.height, backgroundColor);
        drawRectangle(bomb.x, bomb.y, bomb.width, bomb.height, bomb.color);

    } else if (!bomb.erased) {
        drawRectangle(bomb.oldX, bomb.oldY, bomb.width, bomb.height, backgroundColor);
        bomb.erased = 1;

    } // if

} // drawGame

int winCheck() {

    for (int i = 0; i < 20; i++) {

        if (terrain1[i].active) return 0;
        if (terrain2[i].active) return 0;

        if (i > 15) continue;

        if (terrain3[i].active) return 0;
        if (terrain4[i].active) return 0;

    } // for

    return 1;

} // winCheck